Problem one implements a counter outside loops to track how far along `fetch` and `lookup-variable` are.
