The homework problems went well — they were clear, and I solved them without issue.

The lunar lander, though — I had more of an issue with that. The play procedures is borked, but the rest of the lunar lander is implemented under the assumption that the `play` works correctly.